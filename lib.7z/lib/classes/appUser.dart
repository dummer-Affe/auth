import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class Appuser extends GetxController {
  String? _email;
  String? get email => _email;
  User? _user;
  User? get user => _user;

  Future<void> signIn(User user) async {
    if (user.email == null) {
      _email = user.phoneNumber;
    } else {
      _email = user.email!;
    }
    _user = user;

    update();
  }

  Future<void> signOut() async {
    _user = null;
    update();
  }
}
