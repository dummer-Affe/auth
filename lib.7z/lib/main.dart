import 'package:firebase_auth/firebase_auth.dart';
import 'package:firestorage/homePages/homePage.dart';
import 'package:firestorage/loginPages/loginPage.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'classes/appUser.dart';
import 'firebase_options.dart';



late Appuser stateCurrentUser;
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  stateCurrentUser = Get.put(Appuser());
  checkUserAuth();
  runApp(MyApp());
}

void checkUserAuth() {
  FirebaseAuth.instance.authStateChanges().listen((User? user) {
    if (user == null) {
      print('User is currently signed out!');
    } else {
      stateCurrentUser.signIn(user); 
      print('User is signed in!');
    }
  });
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return stateCurrentUser.user == null
        ? MaterialApp(home: LoginPage())
        : MaterialApp(
            title: 'Flutter Demo',
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            home: HomePage());
  }
}
